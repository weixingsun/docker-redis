pkill node
nohup node main.js > node.log 2>&1 &
